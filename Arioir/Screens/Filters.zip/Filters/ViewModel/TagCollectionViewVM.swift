//
//  TagCollectionViewVM.swift
//  Arioir
//
//  Created by Максим Спиридонов on 17.11.2019.
//  Copyright © 2019 Максим Спиридонов. All rights reserved.
//


import UIKit



protocol TagCollectionViewVMType {
    var minimumInteritemSpacingForSectionAt: CGFloat { get }
    var minimumLineSpacingForSectionAt: CGFloat { get }
    func sizeForItemAt(_ indexPath: IndexPath) -> CGSize
    func numberOfRows() -> Int
    func cellViewModel(forIndexPath indexPath: IndexPath) -> TagCollectionViewCellVMType?
    func selectItem(atIndexPath indexPath: IndexPath)
    var onReloadData: (() -> Void)? { get set }
}

class TagCollectionViewVM: TagCollectionViewVMType {
    
    
    
    var onReloadData: (() -> Void)?
    var minimumInteritemSpacingForSectionAt: CGFloat = 12.0
    var minimumLineSpacingForSectionAt: CGFloat = 12.0
    var cells: [TagModel]
    
    init() {
        cells = [TagModel(label: "Стеклярус на флизелине", status: true),
                 TagModel(label: "Текстиль", status: true),
                 TagModel(label: "Бумага", status: false),
                 TagModel(label: "Винил с флоком", status: false),
                 TagModel(label: "Бумага с акрилом", status: true),
                 TagModel(label: "Лак, акрил", status: false),
                 TagModel(label: "Винил", status: true),
                 TagModel(label: "Флизелин с акриловым напылением", status: true),
                 TagModel(label: "Винил", status: false),
                 TagModel(label: "Лак, акрил", status: false),
                 TagModel(label: "Стеклярус на флизелине", status: true),
                 TagModel(label: "Винил", status: false),
                 TagModel(label: "Lak", status: true)]
    }
    
    
    func sizeForItemAt(_ indexPath: IndexPath) -> CGSize {
        
        
        let label = UILabel()
        label.font = label.font.withSize(14)
        label.text = cells[indexPath.row].label
        label.font = UIFont.boldSystemFont(ofSize: 14.0)
        let labelWidth = label.intrinsicContentSize.width + 24

        return CGSize(width: labelWidth, height: 36)
    }
    
    
    func numberOfRows() -> Int {
        return cells.count
    }
    
    func cellViewModel(forIndexPath indexPath: IndexPath) -> TagCollectionViewCellVMType? {
        let cell = cells[indexPath.row]
        return TagCollectionViewCellVM(tag: cell)
    }
    
    func selectItem(atIndexPath indexPath: IndexPath) {
        cells[indexPath.row].status = !cells[indexPath.row].status
        self.onReloadData?()
    }
    
}
