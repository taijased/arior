//
//  TagModel.swift
//  Arioir
//
//  Created by Максим Спиридонов on 17.11.2019.
//  Copyright © 2019 Максим Спиридонов. All rights reserved.
//

import Foundation

struct TagModel {
    let label: String
    var status: Bool
//    init(label: String, status: Bool) {
//        self.label = label
//        self.status = status
//    }
}
